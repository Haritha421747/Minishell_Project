#include "msh.h"
/*declare the variables gobally*/
char prompt[25]="minishell$";
char input_string[25];
char *external_commands[200];
char cmd[20];
Slist *head=NULL;
pid_t delete;
int flag;
int status, count_stop;
pid_t child_pid;

int main()
{
    //first we have to clear the terminal
    system("clear");
    scan_input(prompt, input_string);
}

/*function definition for scaninput.*/
void scan_input(char *prompt, char *input_string)
{
    //call the function store the external commands into one array
    signal(SIGINT,signal_handler1);   //register the signal
    signal(SIGTSTP,signal_handler2);
    extract_external_commands(external_commands);
   
    while(1)
    {
        if(flag)
        {
            while(waitpid(delete, &status, WNOHANG)!=0)
            {
                delete_at_last(&head);
                flag=0;
                break;
            }
        }
        //print the prompt
        printf(ANSI_COLOR_DARK_GREEN);
        printf("%s ",prompt);
        printf(ANSI_COLOR_RESET);
        //read the input string
        printf(ANSI_COLOR_CYAN);
        scanf("%[^\n]",input_string);
        getchar();
        if(!strcmp(input_string,""))
        {
            continue;
        }
        //validate ps1 or not
        if((validate_PS1(prompt,input_string))==SUCCESS)
        {
            continue;
        }
        //get command and store to command variable
        char *command = get_command(input_string);
        //compare the command wit fg
        if(!strcmp(command,"fg"))
        {
            fg(head);
            delete_at_last(&head);
            continue;
        }
        //compare the command wit bg
        if(!strcmp(command,"bg"))
        {
            bg(head);
            flag=1; 
            continue;
        }
        //compare the command wit jobs
        if(!strcmp(command,"jobs"))
        {
            print_list(head);
            continue;
        }
        //call check command
        int check_command=check_command_type(command);
        if(check_command==BUILTIN)             //if command is builtin call internal commands function
        {
            execute_internal_commands(input_string);
        }
        else if(check_command==EXTERNAL)         //check command is external
        {
            //declare the  array of pointer 
            char *argv[20];
            for(int i=0;i<20;i++)
            {
                argv[i]=malloc(20*sizeof(int));
            }
            char str[25];
            /*copy input_string into one array*/
            strcpy(str,input_string);
            int i=0;
            /*copy word by word separated by space into 2d array*/
            char *ret3=strtok(str," ");
            while(ret3!=NULL)
            {
                strcpy(argv[i++],ret3); 
                ret3=strtok(NULL," ");
            }
            argv[i]=NULL;
            //if it is external check pipe is present or not 
            int k=0,pipe_index=0;
            while(argv[k])
            {
                if(!strcmp(argv[k],"|"))
                {
                    pipe_index=1;
                    break;
                }
                k++;
            }
            //create a child process
            pid_t pid=fork();
            if(pid>0)
            {
                //wait until child terminate
                child_pid=pid;
                waitpid(pid,&status,WUNTRACED);
                child_pid=0;
            }
            else if(pid==0)
            {
                if(pipe_index)
                {
                    //excute n_pipe command
                    n_pipe(argv,i);
                    return ;
                }
                else
                {
                    //excute external commands
                    execute_external_commands(argv);
                }
            }
        }
        //if no command     
        else if(check_command==NO_COMMAND)
        {
            printf("%s: command not found\n",input_string);
        }
        //reset input string with 0 
        memset(input_string,0,sizeof(input_string));
    }
}

/*function definition for validate_ps1*/
int validate_PS1(char *prompt, char *input_string)
{
    //intialize a string
    char string[]="PS1=";
    int count=0;
    int i=0;
    //compare string havnig PS1= or not
    while(input_string[i])
    {
        if(input_string[i]==string[i])
        {
            count++;
        }
        else
        {
            break;
        }
        i++;
    }
    //check the string is matching with ps1 or not
    if((input_string[i]!='\0'&&input_string[i]!=' ')&&(count==4))
    {
        char str[100];
        int j=0;
        while(input_string[i]!=' '&&input_string[i])
        {
            str[j++]=input_string[i++];
        }
        str[j]='\0';
        strcpy(prompt,str);
        return SUCCESS;
    }
    //check the string is matching with ps1 or not
    else if((input_string[i]=='\0'&&count==4&&strlen(input_string)==4))
    {
        char str[100];
        int j=0;
        while(input_string[i])
        {
            str[j++]=input_string[i++];
        }
        str[j]='\0';
        strcpy(prompt,str);
        return SUCCESS;
    }
    /*if command not found return no command*/
    else if(count>=1)
    {
        printf("%s: command not found\n",input_string);
        return SUCCESS;
    }
    return FAILURE;
}

/*function defintion for get first command*/
char *get_command(char *input_string)
{
    char str[25];   //declare the array
    /*copy the input string*/
    strcpy(str,input_string);
    strcpy(cmd,strtok(str," "));
    /*return the command*/
    return cmd;     
}

/*function defintion for extract external commands*/
void extract_external_commands(char **external_commands)
{
    /*allocate memory for external commands*/
    for(int i=0;i<200;i++)
    {
        external_commands[i]=calloc(25,sizeof(char));
    }
    /*open file for the external commands*/
    int fd = open("external_commands.txt",O_RDONLY);
    char buffer;
    int i=0,j=0;
    /*read char by char */
    while(read(fd,&buffer,1))
    {
        if(buffer=='\n')
        {
            external_commands[i][j++]='\0';
            j=0;
            i++;
            continue;
        }
        /*store into 2d array*/
        external_commands[i][j++]=buffer;
    }
}
/*function defintion for check command type*/
int check_command_type(char *command)
{
   
    //list of built in commands
    char *builtins[] = {"echo", "printf", "read", "cd", "pwd", "pushd", "popd", "dirs", "let", "eval",
        "set", "unset", "export", "declare", "typeset", "readonly", "getopts", "source",
        "exit", "exec", "shopt", "caller", "true", "type", "hash", "bind", "help", NULL};
    //check whether command is built in or not
    int i=0;
    while(builtins[i])
    {
        if(!strcmp(command,builtins[i]))  //compare command with builtins
        {
            //return builtin
            return BUILTIN;
        }
        i++;
    }
    //compare the command is external or not
    i=0;
    while(i<152)
    {
        
        if(!strcmp(command,external_commands[i]))
        {
            //return external
            return EXTERNAL;
        }
        i++;
    }
    //return no command
    return NO_COMMAND;
}

/*function defintion for execute external commands*/
void execute_internal_commands(char *input_string)
{
    char str[25];
    strcpy(str,input_string);   //copy inputstring to str
    char *res=strtok(str," ");
    //check command is exit then exit from the bash
    if(!strcmp(res,"exit"))
    {
        exit(1);
    }
    //check command is pwd print present working directory
    else if(!strcmp(res,"pwd"))
    {
        char buf[50];
        getcwd(buf,50);       
        printf("%s\n",buf);
    }
    //check command is cd change one directory to another 
    else if(!strcmp(res,"cd"))
    {
        char *res2=strtok(NULL," ");
        if(res2==NULL)
        {
            return ;
        }
        chdir(res2);

    }
    //check command is echo check all conditions and print 
    else if(!strcmp(res,"echo"))
    {
        char *res1=strtok(NULL,"\0");
        if(res1==NULL)
        {
            return ;
        }
        if(!strcmp(res1,"$$"))       
        {
            printf("%d\n",getpid());   //it gives the pid
        }
        else if(!strcmp(res1,"$?"))     
        {
            printf("%d\n",status);     //it give exit status
        }
        
        else if(res1[0]=='$'&&((res1[1]>='A'&&res1[1]<='Z')||(res[1]>='a'&&res[1]<='z')))
        {
            char *res4=strtok(res1,"$");
            char *res5=getenv(res4);
            if(res5!=NULL)
            {
                printf("%s\n",res5);
                return ;
            }
            printf("\n");
        }
        else
        {
            printf("%s\n",res1);
        }
    }
}

/*function defintion for execute_external commands.*/
void execute_external_commands(char **argv)
{
    /*excute commands*/
    execvp(argv[0],argv+0);
}

/*function defintion for n_pipe*/
void n_pipe(char **argv,int size)
{
    int cmd_pos[size];
        int i=0,j=0;
        cmd_pos[j]=0;
        int command_count=0;
        while(argv[i])
        {
            if(!strcmp(argv[i],"|"))  //check for pipe ans store null
            {
                cmd_pos[++j]=i+1;
                argv[i]=NULL;
                command_count++;
            }
            i++;
        }
        int fd[2];
        for(int i=0;i<=command_count;i++)
        {
            if(i!=command_count)
            {
                pipe(fd);
            }
            pid_t pid=fork();
            if(pid>0)
            {
                if(i!=command_count)
                {
                    close(fd[1]);
                    dup2(fd[0],0);
                    close(fd[0]);
                   
                }
                wait(NULL);
            }
            else if(pid==0)
            {
                if(i!=command_count)
                {
                    close(fd[0]);  //close unused fd
                    dup2(fd[1],1);
                }
                execvp(argv[cmd_pos[i]],(argv+cmd_pos[i])); //execute the commands
            }
        }
}

/*function defintion for own signal_handler1*/
void signal_handler1(int signum)
{
    printf(ANSI_COLOR_RED);
    if(child_pid!=0)
    {
        kill(child_pid,SIGINT);
        printf("\n");
    }
    else if(child_pid==0)
    {
        printf(ANSI_COLOR_DARK_GREEN);
        printf("\n%s ",prompt);
        fflush(stdout);
        printf(ANSI_COLOR_RESET);
        
    }

}
/*function defintion for own signal_handler2*/
void signal_handler2(int signum)
{
    printf(ANSI_COLOR_RED);
    if(child_pid!=0)
    {
            kill(child_pid,SIGTSTP);   //stop the proccess
            fflush(stdout);
            count_stop++;
            printf("[%d]+  Stopped      %s\n",count_stop,input_string);   //print the stopped process on terminal
            fflush(stdout);
            insert_at_last(&head,child_pid,input_string);     //cammand to linked list    
    }
    else if(child_pid==0)
    {
        
        printf(ANSI_COLOR_DARK_GREEN);
        printf("\n%s ",prompt);
        fflush(stdout);
        printf(ANSI_COLOR_RESET);
            
    } 
}

/*function defintion for insert_at_last*/
void insert_at_last(Slist **head,int child_pid,char *input_string)
{
    Slist *new = (Slist *)malloc(sizeof(Slist));
    new->pid=child_pid;
    strcpy(new->command,input_string);
    new->link=NULL;
    if((*head)==NULL)
    {
         *head=new;
         return;
    }
    Slist *temp=*head;
    while(temp->link)
    {
        temp=temp->link;
    }
    temp->link=new;
    return;
}
/*function defintion for delete last*/
void delete_at_last(Slist **head)
{
    if(*head==NULL)
    {
        return;
    }
    if((*head)->link==NULL)
    {
        free(*head);
        *head=NULL;
        return;
    }
    Slist *temp=*head;
    Slist *prev=NULL;
    while(temp->link)
    {
        prev=temp;
        temp=temp->link;
    }
    prev->link=NULL;
    free(temp);
    return;
}
/*function definition for pintlist*/
void print_list(Slist *head)
{
    if(head==NULL)
    {
        printf("bash: jobs: current: no such job\n");
        return;
    }
    int i=1;
    while(head)
    {
        if(head->pid == delete)
        printf("[%d] Running           %s\n",i,head->command);
        else
        printf("[%d] Stopped           %s\n",i,head->command);
        i++;
        head=head->link;
    }
}
/*function defintion for fg
resume the stopped process
prompt should not be avialble until it completes*/
void fg(Slist *head)     
{
    if(head==NULL)
    {
        printf("bash: fg: current: no such job\n");
        return;
    }
    while(head->link)
    {
        head=head->link;
    }
    printf("%s\n",head->command);
    printf("%d\n",head->pid);
    kill(head->pid, SIGCONT);
    waitpid(head->pid, &status, WUNTRACED);
    
}
/*function defintion for bg
resume the stopped process
prompt should print immediately.*/
void bg(Slist *head)
{
    //if head is NULL print bash
    if(head == NULL)
    {
        printf("bash: fg: current: no such job\n");
        return;
    }
    //if traverse through the list
    while(head->link)
    {
        head=head->link;
    }
    //if traverse the 
    printf("%s\n",head->command);
    printf("%d\n",head->pid);
     delete = head->pid;
    kill(head->pid, SIGCONT);    
}